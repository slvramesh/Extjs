
// Model
Ext.define('User', {
    extend: 'Ext.data.Model',
    fields: [{
        name: 'id',
        type: 'int'
    }, {
        name: 'name',
        type: 'string'
    }, {
        name: 'email',
        type: 'string'
    }]
});


Ext.onReady(function() {

	// Variable used to hold all the records
	var tempAllData = null;
	
	// Store
    var userStore = Ext.create('Ext.data.Store', {
        storeId: 'user',
        model: 'User',
        autoLoad: 'true',

		listeners: {
			load: function( storeObj, records, successful, operation, eOpts ) {
				// do something after the load finishes
				alert("Initial load 10 records completed");
				
				// Ajax request get all the records
				Ext.Ajax.request({
					url: 'data/sample100.json',

					success: function(response, opts) {
						// Make display all button active
						Ext.getCmp("displayAllData").setDisabled(false);
						tempAllData = Ext.decode(response.responseText);
					},

					failure: function(response, opts) {
						alert('Data Load: server-side failure with status code ' + response.status);
					}
				});
			}
		},
		
		// Load initial 10 records
        proxy: {
            type: 'ajax',
            url: 'data/sample10.json',
            reader: {
                type: 'json',
                root: 'user_lists'
            }
        }
    });

	// Grid panel
    var gridPanel = Ext.create('Ext.grid.Panel', {
        store: userStore,
        id: 'userGridPanel',
		loadMask: true,
		title: 'User Lists',
		forceFit: true,
		style: 'margin: 20px auto auto 50px;',
		height: 300,
        width: 600,
        columns: [{
            header: 'ID',
            dataIndex: 'id',
			width: 20
        }, {
            header: 'Name',
            dataIndex: 'name',
			width: 50
        }, {
            header: 'Email',
            dataIndex: 'email'
        }]
    });

	// Main Panel
	Ext.create('Ext.Panel', {
		id: 'mainPanel',
		title: "Sample Page",
		items: [
			gridPanel,
			{
				xtype: 'button',
				text: 'Display All',
				id: 'displayAllData',
				disabled: true,
				style: 'margin: 20px auto 20px 40%;  align:center',
				handler: function() {
					// Display all data
					alert("Displaying All data");
					
					if((tempAllData != null) && (Object.keys(tempAllData).length > 0)){
						userStore.loadRawData(tempAllData);
					}
					else{
						alert("Error! Not loading all records");
					}
				}
			}
		],
		renderTo: Ext.getBody()
	});
});